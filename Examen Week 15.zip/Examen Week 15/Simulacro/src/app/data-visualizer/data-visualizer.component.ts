import { Component } from '@angular/core';

@Component({
  selector: 'app-data-visualizer',
  imports: [],
  templateUrl: './data-visualizer.component.html',
  styleUrl: './data-visualizer.component.css'
})
export class DataVisualizerComponent {

}
